<?php

return [
    'previous' => '&laquo; ก่อนหน้า',
    'next'     => 'ต่อไป &raquo;',
];
