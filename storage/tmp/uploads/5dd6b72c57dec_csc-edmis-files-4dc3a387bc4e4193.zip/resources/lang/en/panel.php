<?php

return [
    'site_title' => 'CSC-EDMIS',
];
